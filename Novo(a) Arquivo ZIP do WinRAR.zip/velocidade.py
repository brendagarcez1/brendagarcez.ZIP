nome = input("Digite seu nome completo: ")
nome_modificado = nome.replace(' ', '...')
print("Nome modificado:", nome_modificado)

