m = int(input("Qual o valor em joules?"))
c = 3000000
igual= m*c**2
print(f"A energia em joules é igual a {igual}")
