nome = input ("Qual é o seu nome?").strip().lower()
print("Boa tarde, ", nome)

